from faker import Faker
from app import create_app
from app.database import get_db, init_db
from app.utils import hash_phone
import random

fake = Faker()

def seed_data():
    app = create_app()
    with app.app_context():
        # Re-init DB to apply schema changes if needed (beware of data loss in real app)
        # For Hackathon, let's just use what we have or drop tables if we want a clean slate.
        # We'll just insert new data.
        
        db = get_db()
        print("Dropping old tables to refresh schema...")
        db.execute("DROP TABLE IF EXISTS customers")
        db.execute("DROP TABLE IF EXISTS interactions")
        db.execute("DROP TABLE IF EXISTS tickets")
        
        # Re-initialize with new schema
        init_db()
        
        print("Seeding Data...")
        
        # Create a VIP User
        vip_phone = "555000VIP"
        vip_hash = hash_phone(vip_phone)
        
        # Check if exists
        exists = db.execute('SELECT * FROM customers WHERE phone_hash = ?', (vip_hash,)).fetchone()
        if not exists:
            db.execute(
                'INSERT INTO customers (name, phone_hash, language, sentiment_score) VALUES (?, ?, ?, ?)',
                ("Alice VIP", vip_hash, "en", 0.9)
            )
            customer_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]
            
            # Add History
            for _ in range(3):
                db.execute(
                    'INSERT INTO interactions (customer_id, agent_id, summary, status) VALUES (?, ?, ?, ?)',
                    (customer_id, 1, "Previous stay: Luxury Suite. Customer likes extra pillows.", "closed")
                )
                interaction_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]
                
                db.execute(
                    'INSERT INTO tickets (interaction_id, subject, priority, description) VALUES (?, ?, ?, ?)',
                    (interaction_id, "Special Request", "Low", "Extra pillows provided.")
                )
        
        # Create a "Troubled" User
        trouble_phone = "555999BAD"
        trouble_hash = hash_phone(trouble_phone)
        exists = db.execute('SELECT * FROM customers WHERE phone_hash = ?', (trouble_hash,)).fetchone()
        if not exists:
            db.execute(
                'INSERT INTO customers (name, phone_hash, language, sentiment_score) VALUES (?, ?, ?, ?)',
                ("Bob Grumpy", trouble_hash, "es", -0.5)
            )
            customer_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]
            
            # Add History
            db.execute(
                'INSERT INTO interactions (customer_id, agent_id, summary, status) VALUES (?, ?, ?, ?)',
                (customer_id, 1, "Complaint: Noise pollution. Demanded refund.", "closed")
            )
            
        db.commit()
        print(f"Seeded VIP (Phone: {vip_phone}) and Grumpy (Phone: {trouble_phone})")

if __name__ == '__main__':
    seed_data()
