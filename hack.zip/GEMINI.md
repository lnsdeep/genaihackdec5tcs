# Project Overview

This project is a real-time chat application designed for customer support agents. It features an AI co-pilot that assists agents by providing real-time analysis of customer messages, including sentiment analysis, compliance checks for sensitive data (PII), and suggested replies.

**Key Technologies:**

*   **Backend:** Python, Flask, Flask-SocketIO
*   **Frontend:** HTML, JavaScript
*   **AI/NLP:** `openai`, `sentence-transformers`, `spacy`
*   **Database:** SQLite

**Architecture:**

The application follows a typical Flask structure. The backend is organized into several modules:

*   `run.py`: The main entry point for the application.
*   `app/__init__.py`: Initializes the Flask app, extensions, and blueprints.
*   `app/main.py`: Defines the main routes for the application (login, agent console, etc.).
*   `app/events.py`: Contains all the SocketIO event handlers for real-time communication. This is the heart of the application.
*   `app/models.py`: Defines the database schema and provides methods for interacting with the database.
*   `app/agents/`: This directory contains the logic for the different AI agents (Copilot, Sales, Compliance, etc.).
*   `app/static/js/chat.js`: This file contains the frontend SocketIO logic.

The frontend consists of HTML templates rendered by Flask. Real-time updates are handled by JavaScript that communicates with the backend using SocketIO.

# Building and Running

**1. Setup Virtual Environment:**

It is recommended to use a virtual environment to manage project dependencies.

```bash
python -m venv .venv
source .venv/bin/activate  # On Windows use `.venv\Scripts\activate`
```

**2. Install Dependencies:**

```bash
pip install -r requirements.txt
```

**3. Reset Database (Optional):**

If you want to start with a fresh database, you can run the following command:

```bash
python seed_data.py
```

**4. Run the Application:**

```bash
python run.py
```

The application will be available at:
*   **Agent URL:** `http://localhost:5000/agent`
*   **Customer URL:** `http://localhost:5000/customer`

**5. Running Tests:**

To run the tests, you can use the following command:

```bash
python -m unittest discover tests
```

# Development Conventions

*   **Styling:** The project seems to follow the standard PEP 8 style guide for Python code.
*   **Testing:** The `tests` directory suggests that the project has a suite of tests. It's recommended to add new tests for any new features or bug fixes.
*   **Database:** The project uses a SQLite database (`hackathon.db`). The schema is defined in `app/database.py` and the models in `app/models.py`. The `seed_data.py` file can be used to populate the database with initial data.

# Where to make changes?

*   **Chat Logic:** `app/events.py` (backend) and `app/static/js/chat.js` (frontend)
*   **UI/Styling:** `app/templates/`
*   **AI Logic:** `app/agents/`
*   **Database:** `app/database.py`, `app/models.py`, `seed_data.py`