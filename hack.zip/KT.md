# 📘 Developer Knowledge Transfer (KT) - AI Customer Co-Pilot

## 1. Project Overview
**Name**: AI-Powered Customer Experience Assistant
**Goal**: A real-time chat application where Human Agents are assisted by AI Co-pilots.
**Key Features**:
-   **Hybrid Chat**: Real-time communication via WebSockets (`Flask-SocketIO`).
-   **AI Co-Pilot**: Sidebar for agents showing Sentiment, Compliance alerts, and Response Suggestions.
-   **Onboarding Flow**: Multi-lingual customer identification wizard.
-   **Session Management**: Robust state handling (no "ghost" messages).

---

## 2. 📂 Folder Structure Map

Use this map to navigate the codebase.

```text
e:/AGProjects/hack/
├── 📁 app/                     # CORE APPLICTION LOGIC
│   ├── 📁 agents/              # 🧠 THE BRAIN (AI Logic)
│   │   ├── copilot.py          # Central aggregator for all agents.
│   │   ├── sentiment_agent.py  # Analyzes emotion (Positive/Negative).
│   │   ├── compliance_agent.py # Redacts PII (Phone/Credit Cards).
│   │   ├── sales_agent.py      # Suggests upsells/responses (via LLM).
│   │   └── workflow.py         # Automates tasks (Tickets/Callbacks).
│   │
│   ├── 📁 static/              # FRONTEND ASSETS
│   │   └── 📁 js/
│   │       └── chat.js         # ⚡ THE NERVOUS SYSTEM (Frontend Socket Logic).
│   │
│   ├── 📁 templates/           # HTML VIEWS (UI)
│   │   ├── agent_console.html  # The Main Interface for Agents.
│   │   ├── customer_view.html  # The Customer's Chat Portal.
│   │   └── dashboard.html      # Analytics Dashboard.
│   │
│   ├── __init__.py             # App Factory & SocketIO Init.
│   ├── database.py             # SQLite Connection & Schema.
│   ├── events.py               # ❤️ THE HEART (Socket Event Handlers: Join/Msg/Disconnect).
│   ├── models.py               # Database Models (Customer, Interaction).
│   └── utils.py                # Helpers (Phone Hash, Intent Prediction).
│
├── 📁 tests/                   # UNIT TESTS
│   ├── test_ai.py              # Tests for AI Agents.
│   ├── test_socket.py          # Tests for Connection events.
│   ├── test_ghost_message.py   # Tests for Session Security.
│   └── test_disconnect_logic.py# Tests for Disconnect Logic.
│
├── run.py                      # 🚀 ENTRY POINT (Starts the Server).
├── seed_data.py                # 🛠️ DATA TOOL (Resets DB & Adds Dummy Users).
└── requirements.txt            # Python Dependencies.
```

---

## 3. 🗺️ Where do I make changes? (Developer Map)

### 🟥 I want to change HOW the Chat works...
*   **Scenario**: "Messages aren't showing up" or "I want to add a 'User Typing' indicator."
*   **Backend**: Edit `app/events.py`
    *   `handle_join`: User entry logic.
    *   `handle_message`: Broadcasting logic.
*   **Frontend**: Edit `app/static/js/chat.js`
    *   `socket.on('message')`: How received messages are rendered.
    *   `sendMessage()`: How messages are sent.

### 🟦 I want to change the UI / Styling...
*   **Scenario**: "The header color is wrong" or "I want to move the Start Button."
*   **Agent UI**: Edit `app/templates/agent_console.html`.
*   **Customer UI**: Edit `app/templates/customer_view.html` (Logic for the wizard is here too!).
*   **Styling**: See `<style>` blocks in `base.html` or individual templates.

### 🟪 I want to change the AI Logic...
*   **Scenario**: "The Sentiment analysis is too sensitive" or "I want to add a new Resume Agent."
*   **Logic**: Edit `app/agents/copilot.py` (The entry point) or specific agents like `sentiment_agent.py`.
*   **Trigger**: Edit `app/events.py` -> `process_ai_assist` function (This is where AI is called after a message).

### 🟩 I want to change the Database...
*   **Scenario**: "We need to store Customer Email addresses."
*   **Schema**: Edit `app/database.py` (`init_db`).
*   **Model**: Edit `app/models.py`.
*   **Seed Data**: Edit `seed_data.py` to test your new schema.

---

## 4. 🧠 Core Modules Deep Dive

### A. `app/events.py` (The Event Loop)
This file handles all real-time traffic.
*   `handle_join(data)`:
    *   Determines if user is 'customer' or 'agent'.
    *   If **Customer**: Hashes phone -> Looks up DB history -> Emits `customer_profile`.
    *   Joins the Socket Room.
*   `handle_message(data)`:
    *   **CRITICAL**: Checks `active_users` to ensure a customer is actually present (Anti-Ghost).
    *   Broadcasts message to room.
    *   Async calls `process_ai_assist` -> triggers AI agents.

### B. `app/static/js/chat.js` (The Client Controller)
This is the JavaScript running in the browser.
*   `socket.on('status')`: Handles "User Entered/Left". Updates Header text and disables inputs.
*   `toggleInputs(enabled)`: Enforces session state (locks chat if no customer).
*   `socket.emit('message')`: Sends data to server.

### C. `app/models.py` (The Data Logic)
*   `Customer.create`: Handles safe creation (hashing phone numbers).
*   `Interaction.get_history`: Fetches context for the AI.

---

## 5. 🚀 Quick Start for New Devs

1.  **Activate Environment**:
    ```powershell
    & .\.venv\Scripts\Activate.ps1
    ```
2.  **Reset Database** (Optional, if you want fresh data):
    ```powershell
    python seed_data.py
    ```
3.  **Run Application**:
    ```powershell
    python run.py
    ```
    *   Agent URL: `http://localhost:5000/agent`
    *   Customer URL: `http://localhost:5000/customer`
    *   *Login as Alice VIP*: Name: `Alice`, Phone: `555000VIP`

4.  **Run Tests** (Before committing!):
    ```powershell
    python -m unittest discover tests
    ```
