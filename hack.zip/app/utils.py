import hashlib

def hash_phone(phone_number):
    """
    Returns SHA-256 hash of the phone number.
    Standardizes input by removing non-digits.
    """
    if not phone_number:
        return None
        
    # Remove all non-digits
    clean_number = "".join(filter(str.isdigit, str(phone_number)))
    
    
    if not clean_number:
        return None
        
    return hashlib.sha256(clean_number.encode()).hexdigest()

def predict_intent_from_history(history):
    """
    Analyzes past interactions to predict future intent.
    Simple heuristic for Hackathon:
    - If last intent was 'Complaint', predict 'Follow-up on issue'.
    - If last intent was 'Booking', predict 'Modification or Check-in'.
    """
    if not history:
        return "New Customer: Likely Booking Inquiry or General Question."
    
    last_interaction = history[0] # Sorted DESC
    summary = last_interaction['summary'].lower() if last_interaction['summary'] else ""
    
    if "complaint" in summary or "issue" in summary:
        return f"High Probability: Follow-up on previous complaint ('{summary[:30]}...')"
    if "booking" in summary or "reservation" in summary:
        return "Medium Probability: Modification of existing reservation."
        
    return "General Follow-up likely."
