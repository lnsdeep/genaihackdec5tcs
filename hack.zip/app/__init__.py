from flask import Flask
from flask_socketio import SocketIO
from .database import init_db

# Auto-detect async mode (threading, eventlet, gevent, etc.)
socketio = SocketIO(cors_allowed_origins="*")

def create_app(debug=False):
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'dev-secret-key-123'
    app.config['DATABASE'] = 'hackathon.db'

    # Initialize Plugins
    socketio.init_app(app)
    
    with app.app_context():
        init_db()
        
        # Register Blueprints and Routes
        from .main import main as main_blueprint
        app.register_blueprint(main_blueprint)
        
        # Import Events (to register handlers)
        from . import events

    return app
