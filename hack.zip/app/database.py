import sqlite3
from flask import g, current_app

def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(
            current_app.config['DATABASE'],
            detect_types=sqlite3.PARSE_DECLTYPES
        )
        g.db.row_factory = sqlite3.Row
    return g.db

def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def init_db():
    # Simple schema initialization
    db = sqlite3.connect('hackathon.db')
    cursor = db.cursor()
    
    # Customer Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT,
            phone_hash TEXT UNIQUE,
            sentiment_score REAL DEFAULT 0.0,
            language TEXT DEFAULT 'en'
        )
    ''')
    
    # Interaction Table (Chats)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS interactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER,
            agent_id INTEGER,
            start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            summary TEXT,
            status TEXT DEFAULT 'active'
        )
    ''')
    
    # Tickets Table (Mock CRM)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            interaction_id INTEGER,
            subject TEXT,
            priority TEXT,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    db.commit()
    db.close()
