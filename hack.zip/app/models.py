from .database import get_db

class Customer:
    @staticmethod
    def get_by_id(customer_id):
        db = get_db()
        return db.execute('SELECT * FROM customers WHERE id = ?', (customer_id,)).fetchone()

    @staticmethod
    def create(name, email=None, phone=None, language='en'):
        from .utils import hash_phone
        db = get_db()
        
        phone_hash = hash_phone(phone)
        
        # Check if exists by hash
        if phone_hash:
            existing = db.execute('SELECT * FROM customers WHERE phone_hash = ?', (phone_hash,)).fetchone()
            if existing:
                return existing['id']
        
        cursor = db.execute(
            'INSERT INTO customers (name, email, phone_hash, language) VALUES (?, ?, ?, ?)',
            (name, email, phone_hash, language)
        )
        db.commit()
        return cursor.lastrowid
        
    @staticmethod
    def get_by_hash(phone_hash):
        db = get_db()
        return db.execute('SELECT * FROM customers WHERE phone_hash = ?', (phone_hash,)).fetchone()

class Interaction:
    @staticmethod
    def create(customer_id, agent_id=None):
        db = get_db()
        cursor = db.execute(
            'INSERT INTO interactions (customer_id, agent_id) VALUES (?, ?)',
            (customer_id, agent_id)
        )
        db.commit()
        return cursor.lastrowid
    
    @staticmethod
    def update_summary(interaction_id, summary):
        db = get_db()
        db.execute(
            'UPDATE interactions SET summary = ? WHERE id = ?',
            (summary, interaction_id)
        )
        db.commit()

    @staticmethod
    def get_history(customer_id, limit=5):
        db = get_db()
        return db.execute(
            'SELECT * FROM interactions WHERE customer_id = ? ORDER BY start_time DESC LIMIT ?',
            (customer_id, limit)
        ).fetchall()

class Ticket:
    @staticmethod
    def create(interaction_id, subject, priority, description):
        db = get_db()
        db.execute(
            'INSERT INTO tickets (interaction_id, subject, priority, description) VALUES (?, ?, ?, ?)',
            (interaction_id, subject, priority, description)
        )
        db.commit()
