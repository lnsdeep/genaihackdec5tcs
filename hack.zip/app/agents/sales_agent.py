import json
from openai import OpenAI
import os
import re

class SalesAgent:
    def __init__(self):
        # Configure Local LLM
        # Default to localhost for local development
        self.client = OpenAI(
            base_url=os.getenv('LLM_BASE_URL', 'http://localhost:1234/v1'),
            api_key=os.getenv('LLM_API_KEY', 'lm-studio')
        )

    def suggest(self, text, sentiment_data):
        """
        Generate response suggestion and upsell opportunity.
        Returns a dictionary.
        """
        try:
            # Construct Prompt
            prompt = f"""
            You are a helpful Hotel Customer Service Co-pilot.
            Customer says: "{text}"
            Sentiment: {sentiment_data['label']}
            
            Task:
            1. Suggest a helpful response.
            2. Identify if there is an upsell/cross-sell opportunity (Room upgrade, Spa, Late checkout).
            3. Explain WHY you made this suggestion.
            
            Format JSON:
            {{
                "response_suggestion": "...",
                "upsell_opportunity": "..." (or null),
                "reasoning": "..."
            }}
            """
            
            # Call Local LLM
            completion = self.client.chat.completions.create(
                model="local-model", # Model name usually ignored by LM Studio
                messages=[
                    {"role": "system", "content": "Always respond in JSON. Do not include markdown formatting."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7
            )
            
            content = completion.choices[0].message.content
            
            # Clean content (remove markdown code blocks if present)
            content = re.sub(r'```json\s*', '', content)
            content = re.sub(r'```', '', content).strip()
            
            # Parse JSON to ensure it's valid, otherwise throw
            return json.loads(content)

        except Exception as e:
            print(f"LLM Error: {e}")
            return {
                "response_suggestion": "I can help with that.",
                "upsell_opportunity": None,
                "reasoning": f"LLM Unavailable or Error: {str(e)}"
            }
