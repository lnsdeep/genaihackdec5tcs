from .compliance_agent import ComplianceAgent
from .sentiment_agent import SentimentAgent
from .sales_agent import SalesAgent
from .workflow import WorkflowAgent

class CopilotAgent:
    def __init__(self):
        self.compliance = ComplianceAgent()
        self.sentiment = SentimentAgent()
        self.sales = SalesAgent()
        self.workflow = WorkflowAgent()

# Singleton instance
copilot_agent = CopilotAgent()
