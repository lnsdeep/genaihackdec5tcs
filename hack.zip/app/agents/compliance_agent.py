import re

class ComplianceAgent:
    def __init__(self):
        # Regex patterns for common PII
        self.patterns = {
            'EMAIL': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'PHONE': r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
            'CREDIT_CARD': r'\b(?:\d{4}[-\s]?){3}\d{4}\b'
        }

    def redact(self, text):
        """
        Redacts PII from text.
        Returns: (redacted_text, pii_found_boolean)
        """
        redacted_text = text
        pii_found = False
        
        for pii_type, pattern in self.patterns.items():
            if re.search(pattern, redacted_text):
                pii_found = True
                redacted_text = re.sub(pattern, f'[REDACTED_{pii_type}]', redacted_text)
                
        return redacted_text, pii_found
