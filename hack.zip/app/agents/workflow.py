import random
from datetime import datetime, timedelta

class WorkflowAgent:
    def create_ticket(self, interaction_data):
        """
        Mock CRM Ticket Creation
        """
        ticket_id = f"TICKET-{random.randint(1000, 9999)}"
        return {
            "status": "success",
            "ticket_id": ticket_id,
            "message": f"Ticket {ticket_id} created in CRM."
        }
        
    def schedule_callback(self, interaction_data):
        """
        Mock Callback Scheduling
        """
        slot = (datetime.now() + timedelta(hours=1)).strftime("%H:%M")
        return {
            "status": "success",
            "time": slot,
            "message": f"Callback scheduled for today at {slot}."
        }
