import random

class SentimentAgent:
    def analyze(self, text):
        """
        Analyze sentiment.
        Returns: { 'score': float, 'label': str, 'confidence': float }
        """
        # Placeholder: Keyword based for now (or integrate VADER/TextBlob later)
        text_lower = text.lower()
        score = 0.0
        label = 'Neutral'
        
        if any(w in text_lower for w in ['angry', 'bad', 'cancel', 'hate', 'slow', 'stupid']):
            score = -0.8
            label = 'Negative'
        elif any(w in text_lower for w in ['happy', 'good', 'great', 'love', 'thanks']):
            score = 0.8
            label = 'Positive'
        
        return {
            'score': score,
            'label': label,
            'confidence': 0.9
        }
