from flask import request
from flask_socketio import emit, join_room, leave_room
from . import socketio
from .agents.copilot import copilot_agent

# Store active agents and customers
active_users = {}

@socketio.on('connect')
def handle_connect():
    print(f'Client connected: {request.sid}')

@socketio.on('disconnect')
def handle_disconnect():
    print(f'Client disconnected: {request.sid}')
    if request.sid in active_users:
        user = active_users[request.sid]
        username = user.get('username')
        room = user.get('room')
        
        # Notify room
        socketio.emit('status', {'msg': f'{username} has left the chat.', 'type': 'left', 'role': user.get('role')}, room=room)
        
        del active_users[request.sid]

@socketio.on('join')
def handle_join(data):
    username = data.get('username')
    role = data.get('role')
    room = data.get('room')
    metadata = data.get('metadata', {})
    
    # User Identification Flow
    if role == 'customer' and 'phone' in metadata:
        from .models import Customer, Interaction
        customer_id = Customer.create(
            name=username, 
            phone=metadata.get('phone'), 
            language=metadata.get('lang', 'en')
        )
        
        # Look up history
        history = Interaction.get_history(customer_id)
        prediction = "New Customer"
        
        if history:
            from .utils import predict_intent_from_history
            prediction = predict_intent_from_history(history)
            
        # Find agent and emit to them
        agent = next((user for user in active_users.values() if user['role'] == 'agent' and user['room'] == room), None)
        
        if agent:
            # Emit FULL Customer Profile to Agent
            socketio.emit('customer_profile', {
                'name': username,
                'language': metadata.get('lang', 'en'),
                'type': 'VIP' if len(history) > 2 else 'Standard',
                'prediction': prediction,
                'history': [dict(h) for h in history]
            }, room=agent['sid'])
    
    active_users[request.sid] = {'username': username, 'role': role, 'room': room, 'sid': request.sid}
    join_room(room)
    
    emit('status', {'msg': f'{username} has entered the room.', 'role': role}, room=room)

@socketio.on('message')
def handle_message(data):
    """
    Handle incoming chat messages.
    1. Broadcast message to room.
    2. Asynchronously trigger AI Co-pilot analysis.
    """
    room = data.get('room')
    message = data.get('message')
    role = data.get('role') # 'customer' or 'agent'
    
    print(f"Message in {room}: {message}")
    
    # Validation: Ensure customer is in the room if agent is typing
    if role == 'agent':
        # Check active_users for a customer in this room
        has_customer = any(u['role'] == 'customer' and u['room'] == room for u in active_users.values())
        if not has_customer:
            emit('agent_alert', {'type': 'warning', 'msg': 'Cannot send message: Customer is disconnected.'})
            return

    # Broadcast to everyone in room
    emit('message', data, room=room)
    
    # Trigger AI Assistant if message is from Customer
    if role == 'customer':
        # In a real app, this would be a background task (Celery/Redis Queue)
        # For Hackathon, we'll spawn a greenlet or just call it if quick enough.
        # Since we use eventlet, we can just let it handle concurrency.
        socketio.start_background_task(process_ai_assist, room, message)

def process_ai_assist(room, message):
    """
    Run AI agents: Sentiment, Compliance, Suggestion.
    """
    try:
        # 1. Compliance Check (PII)
        redacted_msg, pii_found = copilot_agent.compliance.redact(message)
        if pii_found:
            socketio.emit('agent_alert', {
                'type': 'warning', 
                'msg': 'Sensitive Data Detected & Redacted'
            }, room=room)
        
        # 2. Sentiment Analysis
        sentiment = copilot_agent.sentiment.analyze(redacted_msg)
        socketio.emit('agent_update', {
            'type': 'sentiment',
            'data': sentiment
        }, room=room)
        
        # 3. Suggestions (Only if negative or question?) - For now, always suggest
        suggestions = copilot_agent.sales.suggest(redacted_msg, sentiment)
        socketio.emit('agent_update', {
            'type': 'suggestion',
            'data': suggestions
        }, room=room)
        
    except Exception as e:
        print(f"AI Error: {e}")

@socketio.on('agent_action')
def handle_agent_action(data):
    room = data.get('room')
    action = data.get('action')
    print(f"Action: {action} in {room}")
    
    result = {}
    if action == 'ticket':
        result = copilot_agent.workflow.create_ticket({})
    elif action == 'callback':
        result = copilot_agent.workflow.schedule_callback({})
        
    socketio.emit('agent_alert', {
        'type': 'success',
        'msg': result.get('message', 'Action Completed')
    }, room=room)
