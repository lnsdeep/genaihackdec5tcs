from flask import Blueprint, render_template

main = Blueprint('main', __name__)

@main.route('/')
def index():
    return render_template('login.html')

@main.route('/agent')
def agent_console():
    return render_template('agent_console.html')

@main.route('/customer')
def customer_view():
    return render_template('customer_view.html')

@main.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')
