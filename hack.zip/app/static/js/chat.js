const socket = io();
let myRole = '';
let myUsername = '';
let myRoom = '';

function joinChat(username, role, room, metadata = {}) {
    myRole = role;
    myUsername = username;
    myRoom = room;

    socket.emit('join', { username, role, room, metadata });
}

socket.on('message', function (data) {
    const msgs = document.getElementById('messages');
    const div = document.createElement('div');

    // Check if it's my message
    const isMe = data.role === myRole;
    div.className = `message ${data.role} ${isMe ? 'me' : ''}`;
    div.innerText = data.message;

    // Failsafe: If we receive a message from customer, we are connected.
    if (myRole === 'agent' && data.role === 'customer') {
        document.getElementById('chatStatusText').innerText = "(Customer Connected)";
        document.getElementById('chatStatusText').style.color = '#10b981';
    }

    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
});

// Update UI on Connect/Disconnect
socket.on('status', function (data) {
    // Suppress "Entered" messages from UI to avoid clutter
    if (data.msg.includes('entered')) {
        console.log("Status update:", data.msg);

        // Still update header if it's the customer joining
        if (myRole === 'agent' && data.role === 'customer') {
            document.getElementById('chatStatusText').innerText = "(Customer Connected)";
            document.getElementById('chatStatusText').style.color = '#10b981';
            clearChat();
            toggleInputs(true);
        }
        return;
    }

    const msgs = document.getElementById('messages');
    const div = document.createElement('div');
    div.style.textAlign = 'center';
    div.style.fontSize = '0.8rem';
    div.style.opacity = '0.6';
    div.style.margin = '10px 0';
    div.style.fontStyle = 'italic'; // Style system messages
    div.innerText = data.msg;
    msgs.appendChild(div);

    if (myRole === 'agent' && data.type === 'left') {
        document.getElementById('chatStatusText').innerText = "(Customer Disconnected)";
        document.getElementById('chatStatusText').style.color = '#ef4444';

        // Dim the profile
        document.getElementById('customerProfileCard').style.opacity = '0.5';
        toggleInputs(false);
    }
});

// Update UI with AI Insights (Agent Only)
socket.on('agent_update', function (data) {
    if (myRole !== 'agent') return;

    if (data.type === 'sentiment') {
        const score = data.data.score; // -1 to 1
        const label = data.data.label;

        document.getElementById('sentimentLabel').innerText = label;

        // Emoji & Color
        let emoji = '😐';
        let color = '#94a3b8';
        if (score > 0.3) { emoji = '😀'; color = '#10b981'; }
        else if (score < -0.3) { emoji = '😠'; color = '#ef4444'; }

        document.getElementById('sentimentEmoji').innerText = emoji;
        document.getElementById('sentimentBar').style.backgroundColor = color;

        // Map -1..1 to 0..100%
        const width = ((score + 1) / 2) * 100;
        document.getElementById('sentimentBar').style.width = width + '%';
    }

    if (data.type === 'suggestion') {
        // data.data is a JSON string from LLM usually, or object
        let content = data.data;
        if (typeof content === 'string') {
            try { content = JSON.parse(content); } catch (e) { console.log(e); }
        }

        const area = document.getElementById('suggestionsArea');
        area.innerHTML = ''; // Clear prev

        // Suggestions
        if (content.response_suggestion) {
            const btn = document.createElement('button');
            btn.className = 'suggestion-btn';
            btn.innerText = `💡 ${content.response_suggestion}`;
            btn.onclick = () => {
                document.getElementById('msgInput').value = content.response_suggestion;
            };
            area.appendChild(btn);

            // Reasoning
            const reason = document.createElement('span');
            reason.className = 'suggestion-reason';
            reason.innerText = `Why: ${content.reasoning || 'Matches context'}`;
            area.appendChild(reason);
        }

        // Upsell
        if (content.upsell_opportunity) {
            document.getElementById('salesCard').style.display = 'block';
            document.getElementById('salesText').innerText = content.upsell_opportunity;
        } else {
            document.getElementById('salesCard').style.display = 'none';
        }
    }
});

socket.on('agent_alert', function (data) {
    if (myRole !== 'agent') return;

    const area = document.getElementById('alertsArea');
    const div = document.createElement('div');
    if (data.type === 'success') {
        div.className = 'alert-warning';
        div.style.color = '#10b981';
        div.style.background = 'rgba(16, 185, 129, 0.1)';
        div.style.borderColor = '#10b981';
        div.innerText = `✅ ${data.msg}`;
    } else {
        div.className = 'alert-warning';
        div.innerText = `⚠️ ${data.msg}`;
    }
    area.appendChild(div);

    // Remove after 3s
    setTimeout(() => div.remove(), 3000);
});

// Customer Profile Update (Agent Only)
socket.on('customer_profile', function (data) {
    if (myRole !== 'agent') return;

    document.getElementById('customerProfileCard').style.display = 'block';

    // Redundancy: Ensure header shows connected when profile loads
    document.getElementById('chatStatusText').innerText = "(Customer Connected)";
    document.getElementById('chatStatusText').style.color = '#10b981';
    document.getElementById('customerProfileCard').style.opacity = '1';
    toggleInputs(true);

    document.getElementById('custName').innerText = data.name;
    document.getElementById('custLang').innerText = data.language.toUpperCase();

    const typeSpan = document.getElementById('custType');
    typeSpan.innerText = data.type;
    typeSpan.style.display = data.type === 'VIP' ? 'inline' : 'none';

    document.getElementById('custPrediction').innerText = data.prediction;

    const history = data.history;
    if (history && history.length > 0) {
        document.getElementById('custLastHistory').innerText = history[0].summary || 'No summary';
    } else {
        document.getElementById('custLastHistory').innerText = "New Customer (No History)";
    }
});

// Send Message logic
function sendMessage(role) {
    const input = document.getElementById('msgInput');
    const msg = input.value;
    if (!msg) return;

    socket.emit('message', {
        room: myRoom,
        message: msg,
        role: role,
        username: myUsername
    });

    input.value = '';
}

// Enter key
document.getElementById('msgInput').addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        sendMessage(myRole);
    }
});

// Voice Logic (Web Speech API)
function startVoice(role) {
    if (!('webkitSpeechRecognition' in window)) {
        alert("Web Speech API not supported in this browser.");
        return;
    }

    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'en-US'; // Default, ideally auto-detect
    recognition.start();

    recognition.onresult = function (event) {
        const transcript = event.results[0][0].transcript;
        document.getElementById('msgInput').value = transcript;
    };

    recognition.onerror = function (event) {
        console.error('Speech error', event);
    };
}

function triggerAction(actionType) {
    socket.emit('agent_action', {
        room: myRoom,
        action: actionType,
        username: myUsername
    });
}

// Session Management Helpers
function toggleInputs(enabled) {
    const input = document.getElementById('msgInput');
    const sendBtn = document.getElementById('sendBtn');
    const voiceBtn = document.getElementById('voiceBtn');

    if (enabled) {
        input.disabled = false;
        input.style.background = 'rgba(255,255,255,0.1)';
        input.style.cursor = 'text';

        sendBtn.disabled = false;
        sendBtn.style.opacity = '1';
        sendBtn.style.cursor = 'pointer';

        voiceBtn.disabled = false;
        voiceBtn.style.opacity = '1';
        voiceBtn.style.cursor = 'pointer';
    } else {
        input.disabled = true;
        input.style.background = 'rgba(255,255,255,0.05)';
        input.style.cursor = 'not-allowed';

        sendBtn.disabled = true;
        sendBtn.style.opacity = '0.5';
        sendBtn.style.cursor = 'not-allowed';

        voiceBtn.disabled = true;
        voiceBtn.style.opacity = '0.5';
        voiceBtn.style.cursor = 'not-allowed';
    }
}

function clearChat() {
    const msgs = document.getElementById('messages');
    msgs.innerHTML = '';
}
