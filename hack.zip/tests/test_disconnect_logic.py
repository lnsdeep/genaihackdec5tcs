import unittest
from unittest.mock import patch, MagicMock
from app import create_app, socketio
from app import events

class TestDisconnectLogic(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app.config['TESTING'] = True

    @patch('app.events.emit')
    @patch('app.events.socketio')
    def test_handle_disconnect_logic(self, mock_socketio, mock_emit):
        # Setup: Add a fake user to active_users
        fake_sid = 'test_sid_123'
        events.active_users[fake_sid] = {'username': 'Alice', 'role': 'customer', 'room': 'room-1'}
        
        # Test: Call disconnect handler with mocked request
        with self.app.test_request_context():
            # Mock request.sid
            with patch('app.events.request') as mock_request:
                mock_request.sid = fake_sid
                
                # Execute
                events.handle_disconnect()
                
                # Verify socketio.emit was called with 'left' status
                mock_socketio.emit.assert_called_with(
                    'status', 
                    {'msg': 'Alice has left the chat.', 'type': 'left', 'role': 'customer'}, 
                    room='room-1'
                )
                
                # Verify user removed
                self.assertNotIn(fake_sid, events.active_users)

if __name__ == '__main__':
    unittest.main()
