import unittest
from app.agents.compliance_agent import ComplianceAgent
from app.agents.compliance_agent import ComplianceAgent
from app.agents.sentiment_agent import SentimentAgent
from app.agents.sales_agent import SalesAgent
from unittest.mock import patch, MagicMock

class TestAIAgents(unittest.TestCase):
    def setUp(self):
        self.compliance = ComplianceAgent()
        self.compliance = ComplianceAgent()
        self.sentiment = SentimentAgent()
        self.sales = SalesAgent()

    def test_pii_redaction(self):
        # Phone
        text = "Call me at 555-123-4567 regarding the issue."
        redacted, found = self.compliance.redact(text)
        self.assertTrue(found)
        self.assertIn("[REDACTED_PHONE]", redacted)
        self.assertNotIn("555-123-4567", redacted)
        
        # Email
        text = "Email is john.doe@example.com."
        redacted, found = self.compliance.redact(text)
        self.assertTrue(found)
        self.assertIn("[REDACTED_EMAIL]", redacted)

    def test_sentiment_analysis(self):
        # Negative
        res = self.sentiment.analyze("I am very angry and slow service.")
        self.assertEqual(res['label'], 'Negative')
        self.assertLess(res['score'], 0)
        
        # Positive
        res = self.sentiment.analyze("I love this hotel, great stay!")
        self.assertEqual(res['label'], 'Positive')
        self.assertGreater(res['score'], 0)

    def test_sales_suggest(self):
        # Mock the client on the instance logic
        self.sales.client = MagicMock()
        
        # Mock the LLM response
        mock_completion = MagicMock()
        mock_completion.choices[0].message.content = '{"response_suggestion": "Hello", "upsell_opportunity": "None", "reasoning": "Test"}'
        self.sales.client.chat.completions.create.return_value = mock_completion
        
        # Test success
        res = self.sales.suggest("Hello", {'label': 'Positive'})
        self.assertEqual(res['response_suggestion'], "Hello")
        
        # Test failure (Exception)
        self.sales.client.chat.completions.create.side_effect = Exception("LLM Down")
        res = self.sales.suggest("Hello", {'label': 'Positive'})
        self.assertEqual(res['reasoning'], "LLM Unavailable or Error: LLM Down")

if __name__ == '__main__':
    unittest.main()
