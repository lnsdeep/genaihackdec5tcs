import unittest
from unittest.mock import patch, MagicMock
from app import create_app, socketio, events

class TestGhostMessage(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app.config['TESTING'] = True

    @patch('app.events.emit')
    @patch('app.events.active_users', {}) # Start empty
    def test_reject_ghost_message(self, mock_emit):
        # Setup: Agent is active, but NO customer
        events.active_users['agent_sid'] = {'username': 'Agent', 'role': 'agent', 'room': 'room-1'}
        
        # Test: Agent sends message to 'room-1'
        with self.app.test_request_context():
            # Mock request.sid as agent
            with patch('app.events.request') as mock_request:
                mock_request.sid = 'agent_sid'
                
                data = {'room': 'room-1', 'message': 'Hello?', 'role': 'agent'}
                events.handle_message(data)
                
                # Verify Alert was emitted
                mock_emit.assert_any_call('agent_alert', {'type': 'warning', 'msg': 'Cannot send message: Customer is disconnected.'})
                
                # Verify Message was NOT broadcast (checked via not calling emit with data)
                # Note: emit is called for alert, so we check precise calls
                # ensure 'message' event was NOT emitted
                calls = [args[0] for args in mock_emit.call_args_list]
                self.assertNotIn('message', calls)

    @patch('app.events.emit')
    @patch('app.events.active_users', {}) 
    def test_allow_valid_message(self, mock_emit):
        # Setup: Agent AND Customer in room
        events.active_users['agent_sid'] = {'username': 'Agent', 'role': 'agent', 'room': 'room-1'}
        events.active_users['cust_sid'] = {'username': 'Alice', 'role': 'customer', 'room': 'room-1'}
        
        with self.app.test_request_context():
            with patch('app.events.request') as mock_request:
                mock_request.sid = 'agent_sid'
                data = {'room': 'room-1', 'message': 'Hello Alice', 'role': 'agent'}
                events.handle_message(data)
                
                # Should emit 'message'
                mock_emit.assert_any_call('message', data, room='room-1')

if __name__ == '__main__':
    unittest.main()
