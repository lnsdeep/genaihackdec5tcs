import unittest
from app import create_app, socketio

class TestSocketEvents(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.client = socketio.test_client(self.app)
        
        # Ensure we connect first?
        self.client.connect()

    def test_connect_disconnect(self):
        # 1. Connect
        self.assertTrue(self.client.is_connected())
        
        # 2. Join as Customer
        self.client.emit('join', {
            'username': 'Test User', 
            'role': 'customer', 
            'room': 'room-1'
        })
        
        # Verify join message
        received = self.client.get_received()
        join_msg = next((m for m in received if m['name'] == 'status'), None)
        self.assertIsNotNone(join_msg)
        self.assertIn('Test User has entered', join_msg['args'][0]['msg'])
        
        # 3. Disconnect
        self.client.disconnect()
        
        # Note: In a real unit test with Flask-SocketIO's test_client, receiving the
        # disconnect broadcast *from the same client that disconnected* is tricky because
        # the client is closed. 
        # Typically we need a SECOND client (Agent) to receive the notification.

    def test_user_left_notification(self):
        # Agent connects
        agent = socketio.test_client(self.app)
        agent.emit('join', {'username': 'Agent', 'role': 'agent', 'room': 'room-1'})
        socketio.sleep(0.1)
        
        # Verify Agent actually joined
        agent_msgs = agent.get_received(namespace='/')
        print(f"[DEBUG] Agent Self-Join Msgs: {agent_msgs}")
        
        # Customer connects
        customer = socketio.test_client(self.app)
        customer.emit('join', {'username': 'Alice', 'role': 'customer', 'room': 'room-1'})
        
        # Give server time to process
        socketio.sleep(0.1)
        
        # Agent should see Alice enter
        msgs = agent.get_received()
        
        # Debug
        print(f"\n[DEBUG] Msgs after join: {msgs}")
        
        enter_msg = next((m for m in msgs if m['name'] == 'status'), None)
        if not enter_msg:
             self.fail(f"No status message found in: {msgs}")
             
        self.assertIn('Alice has entered', enter_msg['args'][0]['msg'])
        
        # Customer Disconnects
        customer.disconnect()
        
        # Give server time to process disconnect
        socketio.sleep(0.1)
        
        # Agent should see Alice leave
        msgs = agent.get_received()
        print(f"\n[DEBUG] Msgs after leave: {msgs}")
        
        leave_msg = next((m for m in msgs if m['name'] == 'status'), None)
        
        self.assertIsNotNone(leave_msg, "Agent did not receive leave notification")
        self.assertEqual(leave_msg['args'][0]['type'], 'left')
        self.assertIn('Alice has left', leave_msg['args'][0]['msg'])

if __name__ == '__main__':
    unittest.main()
